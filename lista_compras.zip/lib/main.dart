import 'package:flutter/material.dart';
import 'SplashScreen.dart';

void main() => runApp(MaterialApp(
      title: "Lista de Compras",
      home: SplashScreen(),
      debugShowCheckedModeBanner: false,
    ));
